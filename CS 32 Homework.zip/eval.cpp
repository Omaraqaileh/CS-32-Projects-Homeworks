#include <iostream>
#include <string>
#include <stack>
#include <cassert>
using namespace std;

string convert(string infix, string& postfix);
bool evaluateEXP(const std::string& postfix, const bool values[]);
bool isValid(string infix);

int evaluate(string infix, const bool values[], string& postfix, bool& result) {
	if (isValid(infix)) {
		convert(infix, postfix);
		result = evaluateEXP(postfix, values);
		return 0;
	}
	else {
		return 1;
	}
}
bool highPrecedence(char c1, char c2) {
	if (c1 == c2) {
		return true;
	}
	if (c1 == '!' && c2 == '&') {
		return true;
	}
	if (c1 == '!' && c2 == '|') {
		return true;
	}
	if (c1 == '&' && c2 == '|') {
		return true;
	}
	return false;
}
string convert(string infix, string& postfix) {
	postfix = "";
	stack<char> ConvertStack;
	for (char c : infix) {
		if (isalnum(c)) {
			postfix += c;
		}
		switch (c) {
		case('('):
			ConvertStack.push('(');
			break;
		case(')'):
			while (ConvertStack.top() != '(') {
				postfix += ConvertStack.top();
				ConvertStack.pop();
			}
			ConvertStack.pop();
			break;

		case('&'):
		case('|'):
		case('!'):
			while (!ConvertStack.empty() && ConvertStack.top() != '(' && highPrecedence(ConvertStack.top(), c)) {
				postfix += ConvertStack.top();
				ConvertStack.pop();
			}
			ConvertStack.push(c);
			break;

		}
	}
	while (!ConvertStack.empty()) {
		postfix += ConvertStack.top();
		ConvertStack.pop();
	}
	return postfix;
}
bool evaluateEXP(const std::string& postfix, const bool values[]) {
	std::stack<bool> operandStack;

	for (char c : postfix) {
		if (isdigit(c)) {
			operandStack.push(values[c - '0']);  // Convert char to index
		}
		else if (c == '!') {
			if (operandStack.empty()) {
				return false;
			}
			bool operand = operandStack.top();
			operandStack.pop();
			operandStack.push(!operand);
		}
		else {
			bool operand2 = operandStack.top();
			operandStack.pop();
			bool operand1 = operandStack.top();
			operandStack.pop();
			bool value;

			switch (c) {
			case '|':
				value = operand1 || operand2;
				break;
			case '&':
				value = operand1 && operand2;
				break;
			default:
				throw std::invalid_argument("Invalid operator");
			}
			operandStack.push(value);
		}
	}
	return operandStack.top();
}
bool isValid(string infix) {
	infix.erase(remove(infix.begin(), infix.end(), ' '), infix.end());

	if (infix.empty()) {
		return false;
	}


	for (char c : infix) {
		if (!isdigit(c) && c != '|' && c != '&' && c != '!' && c != '(' && c != ')') {
			return false;
		}
	}

	stack<char> s;
	int nOperands = 0;
	int nOperators = 0;
	int nOpen = 0;
	int nClose = 0;

	for (size_t i = 0; i < infix.size(); ++i) {
		char c = infix[i];

		if (isdigit(c)) {
			if (i + 1 < infix.size() && !(infix[i + 1] == '|' || infix[i + 1] == '&' || infix[i + 1] == ')')) {
				return false;
			}
			nOperands++;
		}
		else if (c == '|' || c == '&') {
			if (i == 0 || (!isdigit(infix[i - 1]) && infix[i - 1] != ')')) {
				return false;
			}
			if (i + 1 >= infix.size() || (!isdigit(infix[i + 1]) && infix[i + 1] != '(' && infix[i + 1] != '!')) {
				return false;
			}
			nOperators++;
		}
		else if (c == '!') {
			if (i + 1 >= infix.size() || (!isdigit(infix[i + 1]) && infix[i + 1] != '(' && infix[i + 1] != '!')) {
				return false;
			}
		}
		else if (c == '(') {
			if (i + 1 >= infix.size() || (!isdigit(infix[i + 1]) && infix[i + 1] != '(' && infix[i + 1] != '!')) {
				return false;
			}
			nOpen++;
			s.push(c);
		}
		else if (c == ')') {
			if (i == 0 || (!isdigit(infix[i - 1]) && infix[i - 1] != ')')) {
				return false;
			}
			nClose++;
			if (s.empty() || s.top() != '(') {
				return false;
			}
			s.pop();
		}
	}

	if (nOpen != nClose) {
		return false;
	}

	if (nOperands != nOperators + 1) {
		return false;
	}

	if (!isdigit(infix.back()) && infix.back() != ')') {
		return false;
	}
	return true;
}
