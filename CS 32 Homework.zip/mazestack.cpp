#include <string>
#include <stack>
#include <iostream>
#include <cassert>
using namespace std;
class Coord
{
public:
    Coord(int r, int c) : m_row(r), m_col(c) {}
    int r() const { return m_row; }
    int c() const { return m_col; }
private:
    int m_row;
    int m_col;
};
bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec) {
    stack<Coord> coordStack;
    Coord a(sr, sc);
    coordStack.push(a);
    maze[sr][sc] = 'a';
    while (!coordStack.empty()) {
        Coord temp = coordStack.top();
        coordStack.pop();
        cout << temp.r();
        cout << temp.c() << endl;
        if (temp.r() == er && temp.c() == ec) {
            return true;
        }
        if (temp.r() > 0 && maze[temp.r() - 1][temp.c()] == '.') {
            Coord b(temp.r() - 1, temp.c());
            coordStack.push(b);
            maze[temp.r() - 1][ temp.c()] = 'a';
        }
        if (temp.c() < nCols - 1 && maze[temp.r()][temp.c() + 1]  == '.') {
            Coord b(temp.r(), temp.c() + 1);
            coordStack.push(b);
            maze[temp.r()][temp.c() + 1] = 'a';
        }
        if (temp.r() < nRows - 1 && maze[temp.r() + 1][temp.c() ] == '.') {
            Coord b(temp.r() + 1, temp.c());
            coordStack.push(b);
            maze[temp.r() + 1][ temp.c()] = 'a';
        }
        if (maze[temp.c() > 0 && temp.r()][temp.c() - 1] == '.') {
            Coord b(temp.r(), temp.c() - 1 );
            coordStack.push(b);
            maze[temp.r()][temp.c() - 1] = 'a';
        }
    }
    return false;
}

