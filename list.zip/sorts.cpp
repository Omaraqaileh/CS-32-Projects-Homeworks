#include <iostream>
#include <algorithm>
#include <numeric>  
#include <utility>
#include <vector>
#include <string>
#include <random>
#include <cassert>

using namespace std;


const bool TEST_INSERTION_SORT = true;


#include <chrono>

class Timer
{
public:
    Timer()
    {
        start();
    }
    void start()
    {
        m_time = std::chrono::high_resolution_clock::now();
    }
    double elapsed() const
    {
        std::chrono::duration<double, std::milli> diff =
            std::chrono::high_resolution_clock::now() - m_time;
        return diff.count();
    }
private:
    std::chrono::high_resolution_clock::time_point m_time;
};
std::random_device aRandomDevice;
std::default_random_engine generator(aRandomDevice());


using IdType = int;

const int NWEEKS = 4 * 52;

struct Store
{
    IdType idNumber;
    double total;
    double weeklySales[NWEEKS];
    Store(IdType i) : idNumber(i)
    {
        std::uniform_int_distribution<> distro(20, 60);
        for (size_t k = 0; k < NWEEKS; k++)
            weeklySales[k] = distro(generator);
        total = accumulate(weeklySales, weeklySales + NWEEKS, 0.0);
    }
};

inline
bool compareStore(const Store& lhs, const Store& rhs)
{
    if (lhs.total > rhs.total)
        return true;
    if (lhs.total < rhs.total)
        return false;
    return lhs.idNumber < rhs.idNumber;
}

inline
bool compareStorePtr(const Store* lhs, const Store* rhs)
{
    return compareStore(*lhs, *rhs);
}

void insertion_sort(vector<Store>& s, bool comp(const Store&, const Store&))
{
    for (size_t to_sort= 1; to_sort < s.size(); to_sort++)
    {
        Store nextItem = s[to_sort]; 
        size_t curlocation = to_sort;

        while (curlocation > 0 && comp(nextItem, s[curlocation - 1]))
        {
            s[curlocation] = s[curlocation - 1];
            curlocation--;
        }


        s[curlocation] = nextItem;
    }
}


void report(string caption, double t, const vector<Store>& s)
{
    cout << t << " milliseconds; " << caption
        << "; first few stores are\n\t";
    size_t sizeN = s.size();
    if (sizeN > 4)
        sizeN = 4;
    for (size_t k = 0; k < sizeN; k++)
        cout << " (" << s[k].idNumber << ", " << s[k].total << ")";
    cout << endl;
}


bool allPresent(const vector<Store>& stores)
{
    vector<int> presentVec(stores.size(), 0);
    for (const auto& s : stores)
        presentVec[s.idNumber] = 1;
    return find(presentVec.begin(), presentVec.end(), 0) == presentVec.end();
}

void sortUsingPtrs(vector<Store>& stores, bool comp(const Store*, const Store*))
{
    vector<Store> auxStores(stores.begin(), stores.end());
    vector<Store*> pointers;
    for (size_t i = 0; i < auxStores.size(); i++)
    {
        pointers.push_back(&auxStores[i]);
    }
    sort(pointers.begin(), pointers.end(), comp);

    for (size_t i = 0; i < stores.size(); i++)
    {
        stores[i] = *pointers[i];
    }
}