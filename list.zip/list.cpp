#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Class
{
public:
    Class(string nm) : m_name(nm) {}
    string name() const { return m_name; }
    const vector<Class*>& subclasses() const { return m_subclasses; }
    void add(Class* d) { m_subclasses.push_back(d); }
    ~Class();
private:
    string m_name;
    vector<Class*> m_subclasses;
};

Class::~Class()
{
    for (size_t k = 0; k < m_subclasses.size(); k++)
        delete m_subclasses[k];
}

void listAll(string path, const Class* c)  
{
    if (c == nullptr)
        return;

    if (path.empty())
        cout << c->name() << endl;
    else
        cout << path << "=>" << c->name() << endl;

    string newPathAvailable = path.empty() ? c->name() : path + "=>" + c->name();

    for (size_t size = 0; size < c->subclasses().size(); size++)
    {
        listAll(newPathAvailable, c->subclasses()[size]);
    }
}

void listAll(const Class* c)
{
    if (c != nullptr)
        listAll("", c);
}
