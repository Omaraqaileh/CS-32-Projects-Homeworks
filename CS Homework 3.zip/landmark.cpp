#include <iostream>
#include <string>
using namespace std;

class Landmark {
private:
    std::string name_landmark;

public:
    Landmark(const std::string& name) : name_landmark(name) {}
    virtual ~Landmark() {}

    virtual const std::string color() const {
        return "yellow";
    }

    virtual const std::string icon() const = 0;

    const std::string name() const {
        return name_landmark;
    }
};

class Hotel : public Landmark {
public:
    Hotel(const std::string& name) : Landmark(name) {}

    ~Hotel() {
        cout << "Destroying the hotel " << name() << "." << endl;
    }

    const std::string icon() const {
        return "bed";
    }
};

class Restaurant : public Landmark {
private:
    int capacity;

public:
    Restaurant(const std::string& name, int capacity) : Landmark(name), capacity(capacity) {}

    ~Restaurant() {
        cout << "Destroying the restaurant " << name() << "." << endl;
    }

    const std::string icon() const {
        if (capacity >= 40) {
            return "large knife/fork";
        }
        else {
            return "small knife/fork";
        }
    }
};

class Hospital : public Landmark {
public:
    Hospital(const std::string& name) : Landmark(name) {}

    ~Hospital() {
        cout << "Destroying the hospital " << name() << "." << endl;
    }

    const std::string color() const {
        return "blue";
    }

    const std::string icon() const {
        return "H";
    }
};


void display(const Landmark* lm) {
    cout << "Display a " << lm->color() << " " << lm->icon() << " icon for "
        << lm->name() << "." << endl;
}

