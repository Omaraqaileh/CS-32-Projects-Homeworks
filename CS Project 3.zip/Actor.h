#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp


class StudentWorld;
class Actor : public GraphObject {
public:
    Actor(int i_ID, int x_c, int y_c, int dir, StudentWorld* mworld);
    virtual void doSomething();
    ~Actor();
    // Getter function for StudentWorld
    StudentWorld* getWorld();
    void setDead();



    virtual bool isAlive();
    virtual bool hasFire();
    virtual bool hasBricks();
    virtual bool hasLadder();
    virtual bool hasBonfire();
    virtual bool hasFloor();
    virtual bool hasKoopa();
    virtual bool hasExtra();
    virtual bool isKong();
    virtual bool hasGarlic();
    virtual void changeCoolDown(int f);
    virtual bool isBarrel();
   
private:
    StudentWorld* m_world; // Pointer to the world this Actor belongs to
    bool health;
};





class Floor : public Actor {
public:
    Floor(int x_coord, int y_coord, StudentWorld* mwrld);
    bool hasBricks();
    bool hasFloor();
    
}

;

class Player : public Actor {
public:
    void increaseBurps(int numBurps);
    Player(int x_coord, int y_coord, StudentWorld* mwrlds);
    void doSomething();
    bool isAlive();
    void setOnLadder(bool s);
    int getBurps();
    void becDead();
    bool onLadder();
    bool blockAbove();
    void becomeFrozen();
    void setBlock(bool s);
private:
    int numWait;
    bool curStatus;
    int numLives;
    int numBurpsRemaining;
    bool isJumping;
    int numTicks;
    bool isOnLadder;
    bool hasBlockAbove;
    bool isFrozen;
};

class FireBall : public Actor {
public: 
    FireBall(int x_coord, int y_coord, StudentWorld* mwrld);
    bool hasFire();
    int randDir();
    void doSomething();
private:
    bool curAlive;
    int numTicksFire;
    bool climbingUp;
    bool climbingDown;
    bool groundBelow;
};

class Ladder : public Actor {
public:
    Ladder(int x_coord, int y_coord, StudentWorld* mworld);
    bool hasLadder();


private:
    
};
class Kong : public Actor {
public:
    Kong(int x_coord, int y_coord, StudentWorld* mworld, int dir);
    bool isKong();
    void doSomething();
    void calcTicks();
private:
    bool fleeState;
    bool calcDistance(int x, int y);
    int lastThrown;
    int numTicks;

};
class Barrel : public Actor {
public:
    Barrel(int x_coord, int y_coord, StudentWorld* mworld, int dir);
    void doSomething();
    bool attack(int newX, int newY, int oldX, int oldY);
    bool isBarrel();
private:
    bool curAlive;
    int countNumTicks;
    bool isFalling;
};
class Koopa : public Actor {
public:
    void doSomething();
    Koopa(int x_coord, int y_coord, StudentWorld* mworld);
    int getKoopaCooldown();
    void checkCooldown();
    void changeCoolDown(int f);
    bool hasKoopa();
private:
    int freezeCooldown;
    int timetoDoStuff;
    bool isMovable;
    
};

class BonFire : public Actor {
public:
    BonFire(int x_coord, int y_coord, StudentWorld* mworld);
    bool hasBonfire();
    void doSomething();
};
class ExtraLife : public Actor {
public:
    ExtraLife(int x_coord, int y_coord, StudentWorld* mworld);
    bool hasExtra();
    void doSomething();
};
class Garlic : public Actor {
public:
    Garlic(int x_coord, int y_coord, StudentWorld* mworld);
    bool hasGarlic();
    void doSomething();
};
class Burp : public Actor {
public:
    Burp(int x_coord, int y_coord, StudentWorld* mworld, int dir);
    void doSomething();
private:
    int lifeTime;
};
#endif // ACTOR_H_
