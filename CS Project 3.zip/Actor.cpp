#include "Actor.h"
#include "StudentWorld.h"
#include <cstdlib>
// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
StudentWorld* Actor::getWorld() {
	return m_world;
}
Actor::~Actor() {
	;
}
Burp::Burp(int x_coord, int y_coord, StudentWorld* mwrld, int dir) : Actor(IID_BURP, x_coord, y_coord, dir, mwrld) {
	lifeTime = 5;
}
bool Actor::isBarrel() {
	return false;
}
bool Barrel::isBarrel() {
	return true;
}
void Burp::doSomething() {
	if (!isAlive()) {
		return;
	}

	if (lifeTime == 0) {
		setDead();
		setVisible(false);
		return;
	}
	lifeTime--;
	
	for (Actor* actor : getWorld()->playerVector()) {
		if (actor->getX() == getX() && actor->getY() == getY()) {
			if (actor->hasKoopa() || actor->hasFire() || actor->isBarrel()) {
				if (actor->hasFire() && (rand() % 3) + 1 == 1) {
					getWorld()->playerVector().push_back(new Garlic(actor->getX(), actor->getY(), getWorld()));
				}
				else if (actor->hasKoopa() && (rand() % 3) + 1 == 1) {
					getWorld()->playerVector().push_back(new ExtraLife(actor->getX(), actor->getY(), getWorld()));
				}
				actor->setDead();
				getWorld()->playSound(SOUND_ENEMY_DIE);
				getWorld()->increaseScore(100);
				
			}
		}
	}
} 

void Actor::changeCoolDown(int f) {
	;
}

void Player::becDead() {
	curStatus = false;
}
int Koopa::getKoopaCooldown() {
	return freezeCooldown;
}
void Koopa::checkCooldown() {
	if (freezeCooldown != 0) {
		freezeCooldown--;
	}
}
void Koopa::changeCoolDown(int f) {
	freezeCooldown = f;
}

bool Actor::hasBonfire() {
	return false;
}
void BonFire::doSomething() {
	/*if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getX() == getY()) {
		getWorld()->decLives();
		getWorld()->player()[0]->becDead();
		getWorld()->playSound(SOUND_PLAYER_DIE);
	}
	*/
	increaseAnimationNumber();
	return;
	
}
bool BonFire::hasBonfire() {
	return true;
}
void Actor::doSomething() {
	;
}
bool Actor::hasFloor() {
	return false;
}
bool Floor::hasFloor() {
	return true;
}

void Actor::setDead() {
	health = false;
}
bool Actor::isAlive() {
	return health;
}
bool Actor::hasLadder() {
	return false;
}
bool Actor::hasFire() {
	return false;
}
bool FireBall::hasFire() {
	return true;
}
bool Ladder::hasLadder() {
	return true;
}
bool Actor::hasKoopa() {
	return false;
}
bool Koopa::hasKoopa() {
	return true;
}
bool Actor::hasExtra() {
	return false;
}
bool Actor::isKong() {
	return false;
}
bool Kong::isKong() {
	return true;
}
bool ExtraLife::hasExtra() {
	return true;
}
Actor::Actor(int i_ID, int x_c, int y_c, int dir, StudentWorld* mworld) : GraphObject(i_ID, x_c, y_c, dir) {
	m_world = mworld;
	health = true;
	
}

int Player::getBurps() {
	return numBurpsRemaining;
}

Player::Player(int x_cord, int y_cord, StudentWorld* mwrlds) : Actor(IID_PLAYER, x_cord, y_cord, right, mwrlds) {
	isJumping = false;
	numTicks = 0;
	numBurpsRemaining = 0;
	numLives = 3;
	hasBlockAbove = false;
	curStatus = true;
	numWait = 0;
	isOnLadder = false;
	isFrozen = false;
}
void Player::setOnLadder(bool s) {
	isOnLadder = s;
}


Koopa::Koopa(int x_coord, int y_coord, StudentWorld* mwrld) : Actor(IID_KOOPA, x_coord, y_coord, (rand() % 2) ? 180 : 0, mwrld) {
	timetoDoStuff = 0;
	freezeCooldown = 0;
}
bool Player::isAlive() {
	return curStatus;
}
Floor::Floor(int x_coord, int y_coord, StudentWorld* mwrld) : Actor(IID_FLOOR, x_coord, y_coord, none, mwrld) {
	;
}
Barrel::Barrel(int x_coord, int y_coord, StudentWorld * mwrld, int dir) : Actor(IID_BARREL, x_coord, y_coord, dir, mwrld) {
	curAlive = true;
	countNumTicks = 0;
	isFalling = false;
}
void Barrel::doSomething() {
	if (!(isAlive())) {
		return;
	}

	// Check for collision with bonfire
	for (Actor* actor : getWorld()->playerVector()) {
		if (actor->getX() == getX() && actor->getY() == getY() && actor->hasBonfire()) {
			setDead();
			setVisible(false);
			break;

		}
	}

	// Check if player is hit
	if (getWorld()->player()[0]->getX() == getX()  && getWorld()->player()[0]->getY() ==  getY()) {
		getWorld()->decLives();
		getWorld()->player()[0]->becDead();
		getWorld()->playSound(SOUND_PLAYER_DIE);
		return;
	}

	// Check for support below (floor or ladder)
	bool hasSupportBelow = false;
	for (Actor* actor : getWorld()->playerVector()) {
		if (actor->getX() == getX() && actor->getY() == getY() - 1 &&
			actor->hasBricks()) {
			hasSupportBelow = true;
			break;
		}
	}

	// Handle falling and direction switching
	if (!hasSupportBelow) {
		moveTo(getX(), getY() - 1);
		isFalling = true;
	}
	else if (isFalling) {
		// Just landed (was falling, now has support)
		
		isFalling = false;
		// Switch direction: right (0) to left (180), left (180) to right (0)
		if (getDirection() == right) {
			setDirection(left);
		}
		else {  // Handles left or any other value (e.g., initial state)
			setDirection(right);
		}
	}

	// Move horizontally if not falling
	if (!isFalling && countNumTicks % 10 == 0) {
		countNumTicks = 0;
		int nextX = (getDirection() == right) ? getX() + 1 : getX() - 1;
		bool blocked = false;
		for (Actor* actor : getWorld()->playerVector()) {
			if (actor->getX() == nextX && actor->getY() == getY() && actor->hasBricks()) {
				blocked = true;
				break;
			}
		}
		if (!blocked) {
			moveTo(nextX, getY());
		}
		else {
			// Optional: Reverse direction when hitting a wall
			setDirection(getDirection() == right ? left : right);
		}
	}
	countNumTicks++;
}

bool Barrel::attack(int newX, int newY, int oldX, int oldY) {
	if (newX == newY && oldX == oldY) {
		return true;
	}
	else {
		return false;
	}
}
Ladder::Ladder(int x_coord, int y_coord, StudentWorld* mworld) : Actor(IID_LADDER, x_coord, y_coord, none, mworld) {
	;
}
FireBall::FireBall(int x_coord, int y_coord, StudentWorld* mwrld) : Actor(IID_FIREBALL, x_coord, y_coord, randDir(), mwrld) {
	curAlive = false;
	numTicksFire = 0;
	climbingUp = false;
	climbingDown = false;
}
Kong::Kong(int x_coord, int y_coord, StudentWorld* mworld, int dir) : Actor(IID_KONG, x_coord, y_coord, dir, mworld) {
	fleeState = false;
	lastThrown = 0;
	numTicks = 0;
}
bool Floor::hasBricks() {
	return true;
}
bool Actor::hasBricks() {
	return false;
}
BonFire::BonFire(int x_coord, int y_coord, StudentWorld* mworld) : Actor(IID_BONFIRE, x_coord, y_coord, none, mworld) {
	
}
ExtraLife::ExtraLife(int x_coord, int y_coord, StudentWorld* mworld) : Actor(IID_EXTRA_LIFE_GOODIE, x_coord, y_coord, 0, mworld) {
	;
}
Garlic::Garlic(int x_coord, int y_coord, StudentWorld* mworld) : Actor(IID_GARLIC_GOODIE, x_coord, y_coord, 0, mworld) {
	;
}

void FireBall::doSomething() {
	// Step 1: If not alive, return immediately
	if (!isAlive()) {
		setVisible(false);
		return;
	}

	// Step 2: Attack player if on same square
	if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getY() == getY()) {
		getWorld()->decLives();
		getWorld()->player()[0]->becDead();
		getWorld()->playSound(SOUND_PLAYER_DIE);
		return;
	}

	// Increment tick counter
	numTicksFire++;

	// Step 3: Perform actions every 10 ticks
	if (numTicksFire % 10 == 0) {
		// Step 3a: Check if current square is climbable (ladder), no solid object above, not climbing down
		bool onLadder = false;
		bool solidAbove = false;
		for (Actor* actor : getWorld()->playerVector()) {
			if (actor->getX() == getX() && actor->getY() == getY() && actor->hasLadder()) {
				onLadder = true;
				break;
			}
			else {
				onLadder = false;
			}
			if (actor->getX() == getX() && actor->getY() == getY() + 1 && (actor->hasBricks())) {
				solidAbove = true;
			}
		}
		if (onLadder && !solidAbove && !climbingDown) {
			if (climbingUp || rand() % 3 == 0) {
				climbingUp = true;
				moveTo(getX(), getY() + 1);
				// Step 3e: Check player collision after moving up
				if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getY() == getY()) {
					getWorld()->decLives();
					getWorld()->player()[0]->becDead();
					getWorld()->playSound(SOUND_PLAYER_DIE);
					return;
				}
				return;  // Skip to end
			}
		}

		// Step 3b: Check if square below is climbable, not climbing up
		bool ladderBelow = false;
		for (Actor* actor : getWorld()->playerVector()) {
			if (actor->getX() == getX() && actor->getY() == getY() - 1 && actor->hasLadder()) {
				ladderBelow = true;
				break;
			}
		}
		if (ladderBelow && !climbingUp) {
			if (climbingDown || (rand() % 3) + 1 == 1) {
				climbingDown = true;
				moveTo(getX(), getY() - 1);

				// Step 3e: Check player collision after moving down
				if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getY() == getY()) {
					getWorld()->decLives();
					getWorld()->player()[0]->becDead();
					getWorld()->playSound(SOUND_PLAYER_DIE);
					return;
				}
				return;  // Skip to end
			}
		}

		// Step 3c: Transition out of climbing state if blocked
		if (climbingUp && !onLadder) {
			climbingUp = false;

		}
		if (climbingDown && !ladderBelow) {
			climbingDown = false;

		}

		// Step 3d: Horizontal movement
		int nextX = (getDirection() == right) ? getX() + 1 : getX() - 1;
		bool solidInFront = false;
		bool supportBelowNext = false;
		for (Actor* actor : getWorld()->playerVector()) {
			if (actor->getX() == nextX && actor->getY() == getY() && actor->hasBricks()) {
				solidInFront = true;
			}
			if (actor->getX() == nextX && actor->getY() == getY() - 1 && (actor->hasBricks() || actor->hasLadder())) {
				supportBelowNext = true;
			}
		}
		
		if (solidInFront || !supportBelowNext) {
			setDirection(getDirection() == right ? left : right);

		
		}
		
		else {
			moveTo(nextX, getY());

		}

		// Step 3e: Check player collision after horizontal move
		if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getY() == getY()) {
			getWorld()->decLives();
			getWorld()->player()[0]->becDead();
			getWorld()->playSound(SOUND_PLAYER_DIE);
			return;
		}
	}
}
void Koopa::doSomething() {
	if (!isAlive()) {
		setVisible(false);
		return;
	}
	if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getY() == getY() && freezeCooldown == 0) {
		getWorld()->player()[0]->becomeFrozen();
		freezeCooldown = 50;
	}
	if (freezeCooldown != 0) {
		freezeCooldown--;
		
	}
	if (timetoDoStuff % 10 == 0) {
		int nextX = (getDirection() == right) ? getX() + 1 : getX() - 1;
		bool solidInFront = false;
		bool supportBelowNext = false;
		for (Actor* actor : getWorld()->playerVector()) {
			if (actor->getX() == nextX && actor->getY() == getY() && actor->hasBricks()) {
				solidInFront = true;
			}
			if (actor->getX() == nextX && actor->getY() == getY() - 1 && (actor->hasBricks() || actor->hasLadder())) {
				supportBelowNext = true;
			}
		}

		if (solidInFront || !supportBelowNext) {
			setDirection(getDirection() == right ? left : right);


		}

		else {
			moveTo(nextX, getY());

		}

	}
	timetoDoStuff++;
}


bool Actor::hasGarlic() {
	return false;
}
void Player::increaseBurps(int numBurps) {
	numBurpsRemaining += numBurps;
}

void Garlic::doSomething() {
	if (!isAlive()) {
		return;
	}
	if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getY() == getY()) {
		getWorld()->increaseScore(25);
		setDead();
		getWorld()->playSound(SOUND_GOT_GOODIE);
		getWorld()->player()[0]->increaseBurps(5);

		setVisible(false);
		
	}
}

void ExtraLife::doSomething() {
	if (!isAlive()) {
		return;
	}
	if (getWorld()->player()[0]->getX() == getX() && getWorld()->player()[0]->getY() == getY()) {
		getWorld()->increaseScore(50);
		setDead();
		getWorld()->playSound(SOUND_GOT_GOODIE);
		getWorld()->incLives();
		setVisible(false);
	}
}
bool Garlic::hasGarlic() {
	return true;
}
void Player::becomeFrozen() {
	isFrozen = true;
}


bool Player::onLadder() {
	return isOnLadder;
}

bool Player::blockAbove() {
	return hasBlockAbove;
}
void Player::setBlock(bool s) {
	hasBlockAbove = s;
}
void Player::doSomething() {
	// Check if not alive
	if (!isAlive()) {
		return;
	}
	if (isFrozen) {
		numWait++;

		if (numWait == 50) {
			isFrozen = false;
			numWait = 0;
		}
		return;
	}
	// Handle jumping sequence
	if (isJumping) {
		int newX = getX();
		int newY = getY();

		// Compute next position based on jump step
		switch (numTicks) {
		case 1:  // Second step: Direction
		case 2:  // Third step: Direction
		case 3:  // Fourth step: Direction
			newX += (getDirection() == right) ? 1 : -1;
			break;
		case 4:  // Fifth step: Down
			newY--;
			break;
		}

		// Check if new position is valid
		bool blocked = false;
		bool onLadderNow = false;

		for (Actor* actor : getWorld()->playerVector()) {
			if (actor->getX() == newX && actor->getY() == newY) {
				if (actor->hasBricks()) {
					blocked = true;
					break;
				}
				if (actor->hasLadder()) {
					onLadderNow = true;
				}
			}
		}

		// Check screen boundaries (assuming 20x20 grid)
		if (newX < 0 || newX >= 20 || newY < 0 || newY >= 20) {
			blocked = true;
		}

		if (!blocked) {
			moveTo(newX, newY);
			if (onLadderNow) {
				isJumping = false;
				numTicks = 0;
				setOnLadder(true);
			}
			else if (numTicks == 4) {
				isJumping = false;
				numTicks = 0;
			}
			else {
				numTicks++;
			}
		}
		else {
			isJumping = false;
			numTicks = 0;
		}
		return;
	}

	// Handle frozen state
	

	// Check for falling
	if (!onLadder() && !isJumping) {
		bool supportBelow = false;
		for (Actor* actor : getWorld()->playerVector()) {
			if (actor->getX() == getX() && actor->getY() == getY() - 1 &&
				(actor->hasBricks() || actor->hasLadder())) {
				supportBelow = true;
				break;
			}
		}
		if (!supportBelow) {
			moveTo(getX(), getY() - 1);
			return;
		}
	}

	// Handle key presses
	int ch;
	if (getWorld()->getKey(ch)) {
		int newX = getX();
		int newY = getY();
		bool blocked = false;
		bool canJump = false;
		switch (ch) {
		case KEY_PRESS_LEFT:
			if (getDirection() != left) {
				setDirection(left);
			}
			else {
				newX--;
			}
			break;
		case KEY_PRESS_RIGHT:
			if (getDirection() != right) {
				setDirection(right);
			}
			else {
				newX++;
			}
			break;
		case KEY_PRESS_UP:
			if (onLadder()) {
				newY++;
			}
			break;
		case KEY_PRESS_DOWN:
			if (onLadder()) {
				newY--;
			}
			break;
		case KEY_PRESS_SPACE:
			// Check if jump is allowed
			for (Actor* actor : getWorld()->playerVector()) {
				if (actor->getX() == getX() &&
					(actor->getY() == getY() - 1 || actor->getY() == getY()) &&
					(actor->hasBricks() || actor->hasLadder())) {
					canJump = true;
					break;
				}
			}
			if (canJump && !blockAbove() && !isJumping) {
				isJumping = true;
				numTicks = 0;
				moveTo(getX(), getY() + 1);  // First step of jump
				getWorld()->playSound(SOUND_JUMP);
			}
			return;
		case KEY_PRESS_TAB:
			if (numBurpsRemaining > 0) {
				numBurpsRemaining--;
				getWorld()->playSound(SOUND_BURP);
				int burpX = (getDirection() == right) ? getX() + 1 : getX() - 1;
				getWorld()->playerVector().push_back(new Burp(burpX, getY(), getWorld(), getDirection()));
			}
			break;
		}

		// Check if movement is blocked
		if ((ch == KEY_PRESS_LEFT || ch == KEY_PRESS_RIGHT ||
			ch == KEY_PRESS_UP || ch == KEY_PRESS_DOWN) &&
			(newX != getX() || newY != getY())) {
			for (Actor* actor : getWorld()->playerVector()) {
				if (actor->getX() == newX && actor->getY() == newY && actor->hasBricks()) {
					blocked = true;
					break;
				}
			}
			if (!blocked && newX >= 0 && newX < 20 && newY >= 0 && newY < 20) {
				moveTo(newX, newY);
			}
		}
	}
}

void Kong::doSomething() {
	if (!isAlive()) {
		return;
	}
	increaseAnimationNumber();
	if (calcDistance(getX(), getY())) {
		fleeState = true;
	}
	calcTicks();
	if (!fleeState) {
		if (lastThrown == numTicks) {
			if (getDirection() == right) {
				getWorld()->playerVector().push_back(new Barrel(getX() + 1, getY(), getWorld(), right));
			}
			else if (getDirection() == left) {
				getWorld()->playerVector().push_back(new Barrel(getX() - 1, getY(), getWorld(), left));
			}
			lastThrown = 0;
		}
	}
	lastThrown++;
	if (lastThrown % 5 == 0) {
		if (fleeState) {
			moveTo(getX(), getY() + 1);
			if (getY() == 20) {
				fleeState = false;
				getWorld()->increaseScore(1000);
				getWorld()->playSound(SOUND_FINISHED_LEVEL);
				getWorld()->finishedLevel();


			}
		}
	}
}

void Kong::calcTicks() {
	numTicks = std::max(200 - 50 * getWorld()->getLevel(), 50);
}
int FireBall::randDir() {
	int rands = rand() % 2;
	if (rands == 0) {
		return left;
	}
	else {
		return right;
	}
}
bool Kong::calcDistance(int x, int y) {
	int distance = abs(x - getWorld()->player()[0]->getX()) + (y - getWorld()->player()[0]->getY());
	if (distance < 2 &&  distance > 0) {
		return true;
	}
	return false;
}