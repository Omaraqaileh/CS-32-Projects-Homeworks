#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <sstream>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

void StudentWorld::finishedLevel() {
    isFinished = true;
}


// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp
void StudentWorld::loadLevel() {
    string curLevel = "level0" + std::to_string(getLevel()) + ".txt";
    Level lev(assetPath());
    Level::LoadResult result = lev.loadLevel(curLevel);
    if (result == Level::load_fail_file_not_found ||
        result == Level::load_fail_bad_format)
    {
        cout << "Something bad happened\n";
        return;
    }
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 20; j++) {
            Level::MazeEntry item = lev.getContentsOf(i, j);
            if (item == Level::player) {
                Player* p;
                vec1.push_back(p);
                vec1[0] = new Player(i, j, this);

            }
            else if (item == Level::floor) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new Floor(i, j, this);

            }
            else if (item == Level::ladder) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new Ladder(i, j, this);
            }
            else if (item == Level::fireball) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new FireBall(i, j, this);
            }
            else if (item == Level::left_kong) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new Kong(i, j, this, 180);
            }
            else if (item == Level::right_kong) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new Kong(i, j, this, 0);
            }
            else if (item == Level::koopa) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new Koopa(i, j, this);
            }
            else if (item == Level::extra_life) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new ExtraLife(i, j, this);
            }
            else if (item == Level::bonfire) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new BonFire(i, j, this);
            }
            else if (item == Level::garlic) {
                Actor* f;
                vec.push_back(f);
                vec[vec.size() - 1] = new Garlic(i, j, this);
            }
        }
    }


}
StudentWorld::StudentWorld(string assetPath)
    : GameWorld(assetPath)
{
    isThat = false;
    isFinished = false;

}

std::string StudentWorld::generate_stats(int S_score, int Level, int Lives,  int Burps_left) {
    string c = "";
    string f = "";
    string b = "";
    string a = "";
    for (int i = 0; i < 7 - std::to_string(S_score).size(); i++) {
        c += "0";
    }
    for (int i = 0; i < 2 - std::to_string(Level).size(); i++) {
        f += "0";
    }
    for (int i = 0; i < 2 - std::to_string(Lives).size(); i++) {
        b += "0";
    }
    for (int i = 0; i < 2 - std::to_string(Burps_left).size(); i++) {
         a += "0";
    }


    return "Score: " + c + std::to_string(S_score) +
        "  Level: " + f + std::to_string(Level) +
        "  Lives: "+ b + std::to_string(Lives) +
        "  Burps: " + a + std::to_string(Burps_left);
}

unsigned int StudentWorld::getCurrentPlayerBurps() {
    return vec1[0]->getBurps();
}
void StudentWorld::setDisplayText()
{
    int score = getScore();
    int level = getLevel();
    int livesLeft = getLives();
    unsigned int burps = getCurrentPlayerBurps();
    // Next, create a string from your statistics, of the form:
    // Score: 0000100 Level: 03 Lives: 03 Burps: 08
    string s = generate_stats(score, level, livesLeft, burps);
    // Finally, update the display text at the top of the screen with your
    // newly created stats
    setGameStatText(s); // calls our provided GameWorld::setGameStatText
}
StudentWorld::~StudentWorld() {
    cleanUp();
}

int StudentWorld::init()
{
    string curLevel = "level0" + std::to_string(getLevel()) + ".txt";
    Level lev(assetPath());
    Level::LoadResult result = lev.loadLevel(curLevel);
    if (result == Level::load_fail_file_not_found || getLevel() == 99)
    {
        return GWSTATUS_PLAYER_WON;
    }
    if (result == Level::load_fail_bad_format) {
        return GWSTATUS_LEVEL_ERROR;
    }
    loadLevel();
    return GWSTATUS_CONTINUE_GAME;
}
void StudentWorld::setThat(bool that) {
    isThat = that;
}
std::vector<Actor*>& StudentWorld::playerVector() {
    return vec;
}
int StudentWorld::move()
{
    bool yes = false;
    // This code is here merely to allow the game to build, run, and terminate after you type q
    bool currTaken = false;
    if (!(vec1[0]->isAlive())) {
        return GWSTATUS_PLAYER_DIED;
    }
    std::vector<Actor*>::iterator it = vec.begin();
    while (it != vec.end()) {
        if (!(*it)->isAlive()) {
            delete* it;
            it = vec.erase(it);

        }
        else {
            it++;
        }
    }
    vec1[0]->doSomething();
    for (int i = 0; i < vec.size(); ++i) {
        if (vec[i]->isAlive()) {
            vec[i]->doSomething();

        }
        if (vec[i]->hasLadder()) {
            int ladderX = vec[i]->getX();
            int ladderY = vec[i]->getY();

            if (vec1[0]->getX() == ladderX &&
                (vec1[0]->getY() == ladderY || vec1[0]->getY() == ladderY + 1)) {
                vec1[0]->setOnLadder(true);
                currTaken = true;
            }
        }
        if (vec[i]->getX() == vec1[0]->getX() && vec[i]->getY() == vec1[0]->getY()) {

            if (vec[i]->hasBricks()) {
                if (vec1[0]->getDirection() == 0) {
                    vec1[0]->moveTo(vec1[0]->getX() - 1, vec1[0]->getY());
                }
                else {
                    vec1[0]->moveTo(vec1[0]->getX() + 1, vec1[0]->getY());
                }
            }
            
            if (vec[i]->hasBonfire()) {
                if (vec[i]->getX() == vec1[0]->getX() && vec[i]->getY() == vec1[0]->getY()) {
                    decLives();
                    vec1[0]->becDead();
                    vec1[0]->getWorld()->playSound(SOUND_PLAYER_DIE);
                }

            }
        }
        if (vec[i]->getX() == vec1[0]->getX() && vec[i]->getY() == vec1[0]->getY() + 1) {
            if (vec[i]->hasBricks()) {
                vec1[0]->setBlock(true);
                yes = true;
            }
        }
    }
    if (isFinished) {
        isFinished = false;
        return GWSTATUS_FINISHED_LEVEL;
    }
    if (!currTaken) {
        vec1[0]->setOnLadder(false);
    }
    if (!yes) {
        vec1[0]->setBlock(false);
    }
    setDisplayText();

    return GWSTATUS_CONTINUE_GAME;
}

std::vector<Player*>& StudentWorld::player() {
    return vec1;
}
void StudentWorld::cleanUp()
{
    if (vec1.size() != 0 && vec.size() != 0) {

        vector<Player*>::iterator it1;
        it1 = vec1.begin();
        delete* it1;
        it1 = vec1.erase(it1);
        vector<Actor*>::iterator it;
        it = vec.begin();
        while (it != vec.end()) {

            delete* it;
            it = vec.erase(it);
        }
    }
}
