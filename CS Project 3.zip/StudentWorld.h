#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include "Level.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	
	StudentWorld(std::string assetPath);
	~StudentWorld();
	virtual int init();
	virtual int move();
	virtual void cleanUp();
	void setDisplayText();
	unsigned int getCurrentPlayerBurps();
	void setThat(bool that);
	void finishedLevel();

	std::vector <Player*>& player();
	std::vector<Actor*>& playerVector();
	std::string generate_stats(int S_score, int Level, int Lives, int Burps_Left);
private:
	std::vector<Actor*> vec;
	std::vector <Player*> vec1;
	void loadLevel();
	bool isThat;
	bool isFinished;
};

#endif // STUDENTWORLD_H_
