#ifndef SEQUENCE_H
#define SEQUENCE_H

#include <iostream>
#include <string>

const int DEFAULT_MAX_ITEMS = 140;
using ItemType = std::string;

class Sequence {
private:
    class LinkedList {
    private:
        struct Node {
            ItemType value;
            Node* next;
            Node* prev;
        };
        int ll_size;
        Node* head_;
        Node* tail_;

    public:
        LinkedList();
        ~LinkedList();
        void copy(const LinkedList& other);
        int insert_List(int pos, const ItemType& val);
        int insert_List_Alp(const ItemType& val);
        void destructor();
        int find_Node(const ItemType& val) const;
        bool set_Node(int pos, const ItemType& val);
        bool get_Value(int pos, ItemType& value) const;
        bool erase_Node(int pos);
        int remove_Node(const ItemType& val);
        void swap_List(LinkedList& other);
        int link_ListSize() const;
    };

    LinkedList TESTList;

public:
    Sequence();
    ~Sequence();
    Sequence(const Sequence& other);
    Sequence& operator=(const Sequence& seq);

    bool empty() const;
    int size() const;
    int insert(int pos, const ItemType& value);
    int insert(const ItemType& value);
    bool erase(int pos);
    int remove(const ItemType& value);
    bool get(int pos, ItemType& value) const;
    bool set(int pos, const ItemType& value);
    int find(const ItemType& value) const;
    void swap(Sequence& other);
};

// Non-member function declarations
int subsequence(const Sequence& seq1, const Sequence& seq2);
void zipper(const Sequence& seq1, const Sequence& seq2, Sequence& result);

#endif // SEQUENCE_H
