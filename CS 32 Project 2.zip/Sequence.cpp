#include "Sequence.h"

Sequence::LinkedList::LinkedList() : head_(nullptr), tail_(nullptr), ll_size(0) {}

Sequence::LinkedList::~LinkedList() {
    destructor();
}

void Sequence::LinkedList::destructor() {
    Node* current = head_;
    while (current) {
        Node* temp = current->next;
        delete current;
        current = temp;
    }
    head_ = tail_ = nullptr;
    ll_size = 0;
}

int Sequence::LinkedList::link_ListSize() const {
    return ll_size;
}

void Sequence::LinkedList::copy(const LinkedList& other) {
    destructor();
    Node* sourceNode = other.head_;
    Node* prevNode = nullptr;

    while (sourceNode != nullptr) {
        Node* newNode = new Node;
        newNode->value = sourceNode->value;
        newNode->prev = prevNode;
        newNode->next = nullptr;

        if (prevNode == nullptr) {
            head_ = newNode;
        }
        else {
            prevNode->next = newNode;
        }

        prevNode = newNode;
        sourceNode = sourceNode->next;
    }

    ll_size = other.ll_size;
}

int Sequence::LinkedList::insert_List(int pos, const ItemType& val) {
    if (pos < 0 || pos > ll_size) {
        return -1;
    }

    Node* newNode = new Node{ val, nullptr, nullptr };

    if (pos == 0) {
        newNode->next = head_;
        if (head_) {
            head_->prev = newNode;
        }
        else {
            tail_ = newNode;
        }
        head_ = newNode;
    }
    else if (pos == ll_size) {
        newNode->prev = tail_;
        if (tail_) {
            tail_->next = newNode;
        }
        tail_ = newNode;
    }
    else {
        Node* current = head_;
        for (int i = 0; i < pos - 1; i++) {
            current = current->next;
        }
        newNode->next = current->next;
        newNode->prev = current;
        current->next->prev = newNode;
        current->next = newNode;
    }

    ll_size++;
    return pos;
}

int Sequence::LinkedList::insert_List_Alp(const ItemType& val) {
    Node* current = head_;
    int pos = 0;

    while (current != nullptr && current->value < val) {
        current = current->next;
        pos++;
    }

    return insert_List(pos, val);
}

bool Sequence::LinkedList::erase_Node(int pos) {
    if (pos < 0 || pos >= ll_size) {
        return false;
    }

    Node* current = head_;

    if (pos == 0) {
        head_ = head_->next;
        if (head_) {
            head_->prev = nullptr;
        }
        else {
            tail_ = nullptr;
        }
    }
    else {
        for (int i = 0; i < pos; i++) {
            current = current->next;
        }
        current->prev->next = current->next;
        if (current->next) {
            current->next->prev = current->prev;
        }
        else {
            tail_ = current->prev;
        }
    }

    delete current;
    ll_size--;
    return true;
}

int Sequence::LinkedList::remove_Node(const ItemType& val) {
    int count = 0;
    Node* current = head_;

    while (current) {
        if (current->value == val) {
            Node* temp = current->next;
            erase_Node(count);
            current = temp;
        }
        else {
            current = current->next;
            count++;
        }
    }

    return count;
}

bool Sequence::LinkedList::set_Node(int pos, const ItemType& val) {
    if (pos < 0 || pos >= ll_size) {
        return false;
    }

    Node* current = head_;
    for (int i = 0; i < pos; i++) {
        current = current->next;
    }

    current->value = val;
    return true;
}

bool Sequence::LinkedList::get_Value(int pos, ItemType& value) const {
    if (pos < 0 || pos >= ll_size) {
        return false;
    }

    Node* current = head_;
    for (int i = 0; i < pos; i++) {
        current = current->next;
    }

    value = current->value;
    return true;
}

int Sequence::LinkedList::find_Node(const ItemType& val) const {
    Node* current = head_;
    int pos = 0;

    while (current) {
        if (current->value == val) {
            return pos;
        }
        current = current->next;
        pos++;
    }

    return -1;
}

void Sequence::LinkedList::swap_List(LinkedList& other) {
    std::swap(head_, other.head_);
    std::swap(tail_, other.tail_);
    std::swap(ll_size, other.ll_size);
}

Sequence::Sequence() {}

Sequence::~Sequence() {
    TESTList.destructor();
}

Sequence::Sequence(const Sequence& other) {
    TESTList.copy(other.TESTList);
}

Sequence& Sequence::operator=(const Sequence& seq) {
    if (this != &seq) {
        TESTList.copy(seq.TESTList);
    }
    return *this;
}

bool Sequence::empty() const {
    return TESTList.link_ListSize() == 0;
}

int Sequence::size() const {
    return TESTList.link_ListSize();
}

int Sequence::insert(int pos, const ItemType& value) {
    return TESTList.insert_List(pos, value);
}

int Sequence::insert(const ItemType& value) {
    return TESTList.insert_List_Alp(value);
}

bool Sequence::erase(int pos) {
    return TESTList.erase_Node(pos);
}

int Sequence::remove(const ItemType& value) {
    return TESTList.remove_Node(value);
}

bool Sequence::get(int pos, ItemType& value) const {
    return TESTList.get_Value(pos, value);
}

bool Sequence::set(int pos, const ItemType& value) {
    return TESTList.set_Node(pos, value);
}

int Sequence::find(const ItemType& value) const {
    return TESTList.find_Node(value);
}

void Sequence::swap(Sequence& other) {
    TESTList.swap_List(other.TESTList);
}

// Non-member function implementations
int subsequence(const Sequence& seq1, const Sequence& seq2) {
    if (seq2.empty() || seq2.size() > seq1.size()) {
        return -1;
    }

    for (int i = 0; i <= seq1.size() - seq2.size(); i++) {
        bool match = true;
        for (int j = 0; j < seq2.size(); j++) {
            ItemType val1, val2;
            seq1.get(i + j, val1);
            seq2.get(j, val2);
            if (val1 != val2) {
                match = false;
                break;
            }
        }
        if (match) {
            return i;
        }
    }

    return -1;
}

void zipper(const Sequence& seq1, const Sequence& seq2, Sequence& result) {
    Sequence temp;
    int i = 0, j = 0;

    while (i < seq1.size() || j < seq2.size()) {
        if (i < seq1.size()) {
            ItemType val;
            seq1.get(i++, val);
            temp.insert(temp.size(), val);
        }
        if (j < seq2.size()) {
            ItemType val;
            seq2.get(j++, val);
            temp.insert(temp.size(), val);
        }
    }

    result.swap(temp);
}